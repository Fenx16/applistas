package com.example.caaaampeeonesoeslazy.ui.theme

sealed class campantalla (  val ruta:String
    ) {
        object inicio : campantalla("inicio")
        object info : campantalla("info/{nombre}") {

            fun cambiarcamp(nombre: String) = "info/$nombre"
        }
    }
