package com.example.caaaampeeonesoeslazy

data class Campeones(
    val nombre:String,
    val descripcion:String,
    val imagen:String,
    val region:String,
    val rol:String,
    )