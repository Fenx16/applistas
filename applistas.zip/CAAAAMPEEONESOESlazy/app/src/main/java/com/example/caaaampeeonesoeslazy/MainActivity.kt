package com.example.caaaampeeonesoeslazy

import android.os.Bundle
import coil.compose.rememberImagePainter
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import coil.compose.ImagePainter
import com.example.caaaampeeonesoeslazy.ui.theme.CAAAAMPEEONESOESlazyTheme
import com.example.caaaampeeonesoeslazy.ui.theme.campantalla
import java.net.URL

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CAAAAMPEEONESOESlazyTheme {
                // A surface container using the 'background' color from the theme
                Surface(color = MaterialTheme.colors.background) {
                    NavigationHost()
                }
            }
        }
    }
}

fun getCamp(): List<Campeones>{
    val listaCampeones =  listOf(
        Campeones(
            "Anivia, la criofénix",
            "Anivia es un espíritu alado benevolente que soporta ciclos interminables de vida, muerte y nacimiento para proteger Freljord. Semidiosa nacida del hielo implacable y los vientos crueles, canaliza estos poderes elementales para anular a cualquiera que se atreva a perturbar su hogar.",
            "https://esports.eldesmarque.com/wp-content/uploads/2017/01/Anivia_0.jpg",
            "Freljord",
            "Mago,"

        ),
        Campeones(
            "Jinx, la bala perdida",
            "Jinx, una criminal perturbada e impulsiva de Zaun, vive para sembrar el caos sin importarle las consecuencias. Provoca las explosiones más ruidosas y cegadoras con su arsenal de armas letales para dejar un rastro de terror y destrucción a su paso. Jinx aborrece el aburrimiento y disfruta dejando su peculiar impronta allá donde va.",
            "https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Jinx_0.jpg",
            "Zaun",
            "Tirador",
        ),

        Campeones(
            "Rengar, el acechador orgulloso",
            "Rengar es un feroz cazador de trofeos vastaya que vive por el placer de perseguir y asesinar criaturas peligrosas. Explora el mundo en busca de las bestias más aterradoras, pero, ante todo, quiere encontrar alguna pista que lo lleve hasta Kha'Zix, la criatura del Vacío que le arrebató un ojo.",
            "https://cdnb.artstation.com/p/assets/images/images/000/513/333/large/jason-chan-0910-rengar-1.jpg?1443929423&dl=1",
            "Ixtal",
            "Asesino",
        ),
        Campeones(
            "Kha'Zix",
            "El Vacío crece y el Vacío se adapta; verdades que son más evidentes en Kha'Zix que en ningún otro de sus innumerables engendros. La evolución impulsa el núcleo de este horror mutante, nacido para sobrevivir y matar a los fuertes.",
            "https://cdnb.artstation.com/p/assets/images/images/000/404/367/large/joshua-brian-smith-khazix.jpg?1512716251",
            "EL vacio",
            "Asesino"
        ),
        Campeones(
        "Swain, el gran general de Noxus",
        "Jericho Swain es el visionario líder de Noxus, una nación expansionista que solo venera la fuerza. Pese a haber sido relegado y a haber perdido el brazo izquierdo en las guerras de Jonia, se hizo con el control del imperio con una despiadada determinación... y una nueva mano demoníaca.",
                "https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Swain_0.jpg",
        "Noxus",
        "Mago",
        )
    )

    return listaCampeones
}


@Composable
fun inicio(navController: NavController) {
    LazyColumn(
        contentPadding = PaddingValues(10.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        horizontalAlignment = Alignment.Start,
        modifier = Modifier
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF06722E),
                        Color(0xFF160C0B),
                    )))

    )
    {
         items( getCamp()) { campeon ->
            Card(

                modifier = Modifier

                    .clickable(onClick = {
                        navController.navigate(
                            campantalla.info.cambiarcamp(
                                campeon.nombre
                            )
                        )
                    })
                    .background(
                        MaterialTheme.colors.primary,
                    )
                    .padding(horizontal = 1.dp, vertical = 2.dp)
                    .fillMaxSize(), elevation = 2.dp,

                shape = RectangleShape,


                )

            {
                CargarImagen(url = campeon.imagen)


            }
        }
    }
}

@Composable
fun info(Nombre: String, navController: NavController) {
    val lista = getCamp()
    var campselect = Campeones("", "", "", "", "")

    for (Campeones in lista) {
        if (Campeones.nombre == Nombre) {
            campselect = Campeones
        }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF06722E),
                        Color(0xFF160C0B),
                    )
                )
            )
            .fillMaxWidth()
            .fillMaxHeight()

            .padding(14.dp)
    ) {


        Row(
            modifier = Modifier
                .background(Color.Transparent)
                .fillMaxWidth()
                .padding(start = 10.dp)
        ) {
            Text(
                text = campselect.nombre,
                color = Color.White,
                fontStyle = FontStyle.Normal,
                fontWeight = FontWeight.Bold,
                fontSize = 30.sp,
                lineHeight = 2.em,
            )
        }

        Row(

            modifier = Modifier

                .width(200.dp)
                .height(250.dp)
        ) {
            CargarImagenCompleta(url = campselect.imagen)
        }


        Row(modifier = Modifier
            .fillMaxWidth()
            .height(190.dp)) {

            Text(
                text =  campselect.descripcion,
                color = Color.White,
                fontStyle = FontStyle.Italic,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                lineHeight = 2.em,

            )
        }

        Row {
            Text(
                text = campselect.region.toString(),
                color = Color.White,
                lineHeight = 2.em,
                textAlign = TextAlign.Center
            )
        }


        Row {
            Text(
                text = campselect.rol,
                color = Color.White,
                lineHeight = 2.em,
                textAlign = TextAlign.Center
            )
        }

        Button(
            onClick = { navController.navigate(campantalla.inicio.ruta) },
            colors = ButtonDefaults.buttonColors(
              backgroundColor = Color.Cyan
            ),
            modifier = Modifier
                .padding(top = 35.dp)

        ) {
            Text(text = "Pulse para volver a la pantalla de inicio"

            )
        }
    }
}



@Composable
fun NavigationHost() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = campantalla.inicio.ruta) {
        composable(campantalla.inicio.ruta) {
            inicio(navController = navController)
        }

        composable(campantalla.info.ruta) { navBackStackEntry ->
            var nombre = navBackStackEntry.arguments?.getString("nombre")
            info(nombre!!, navController = navController)
        }
    }

}


@Composable
fun CargarImagen(url: String) {
    Image(
        painter = rememberImagePainter(url),
        contentDescription = "imagePadding",
        modifier = Modifier

            .padding(1.dp)
            .height(120.dp)

        , alignment = Alignment.BottomStart ,

        contentScale = ContentScale.FillBounds)
}
@Composable
fun CargarImagenCompleta(url: String) {
    Image(
        painter = rememberImagePainter(url), contentDescription = "Imagen",
        modifier = Modifier
            .height(220.dp)
            .width(220.dp)
            .padding(0.dp),

        contentScale = ContentScale.Fit
        ,
    )
}